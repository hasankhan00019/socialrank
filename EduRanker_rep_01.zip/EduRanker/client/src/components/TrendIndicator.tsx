import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface TrendIndicatorProps {
  value: number;
  suffix?: string;
}

export default function TrendIndicator({ value, suffix = "%" }: TrendIndicatorProps) {
  const isPositive = value > 0;
  const isNeutral = value === 0;

  return (
    <span
      className={`inline-flex items-center gap-1 text-sm font-medium ${
        isNeutral
          ? "text-muted-foreground"
          : isPositive
          ? "text-chart-2"
          : "text-destructive"
      }`}
      data-testid="trend-indicator"
    >
      {isNeutral ? (
        <Minus className="h-4 w-4" />
      ) : isPositive ? (
        <TrendingUp className="h-4 w-4" />
      ) : (
        <TrendingDown className="h-4 w-4" />
      )}
      <span className="font-mono">
        {isPositive && "+"}{Math.abs(value)}{suffix}
      </span>
    </span>
  );
}
