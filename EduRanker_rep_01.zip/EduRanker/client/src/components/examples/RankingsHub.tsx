import RankingsHub from '../../pages/RankingsHub';

export default function RankingsHubExample() {
  return <RankingsHub />;
}
