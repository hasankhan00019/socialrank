import StatCard from '../StatCard';
import { Building2 } from 'lucide-react';

export default function StatCardExample() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <StatCard
        title="Total Institutions"
        value="1,247"
        icon={Building2}
        trend={{ value: "12% this month", positive: true }}
      />
      <StatCard
        title="Total Institutions"
        value="1,247"
        icon={Building2}
      />
    </div>
  );
}
