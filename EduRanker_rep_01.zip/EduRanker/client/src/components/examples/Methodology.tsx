import Methodology from '../../pages/Methodology';

export default function MethodologyExample() {
  return <Methodology />;
}
