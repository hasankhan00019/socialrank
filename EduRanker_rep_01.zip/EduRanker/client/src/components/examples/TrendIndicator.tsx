import TrendIndicator from '../TrendIndicator';

export default function TrendIndicatorExample() {
  return (
    <div className="flex flex-col gap-4">
      <TrendIndicator value={12.5} />
      <TrendIndicator value={-8.3} />
      <TrendIndicator value={0} />
    </div>
  );
}
