import BlogPost from '../../pages/BlogPost';

export default function BlogPostExample() {
  return <BlogPost />;
}
