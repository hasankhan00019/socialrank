import RankingCard from '../RankingCard';

export default function RankingCardExample() {
  return (
    <div className="space-y-4">
      <RankingCard
        rank={1}
        institutionId="harvard"
        institutionName="Harvard University"
        country="United States"
        score={95.8}
        followers={2500000}
        engagement={4.2}
        trend={8.5}
      />
      <RankingCard
        rank={2}
        institutionId="stanford"
        institutionName="Stanford University"
        country="United States"
        score={92.3}
        followers={2100000}
        engagement={3.9}
        trend={-2.1}
      />
    </div>
  );
}
