import PlatformBadge from '../PlatformBadge';

export default function PlatformBadgeExample() {
  return (
    <div className="flex flex-wrap gap-2">
      <PlatformBadge platform="facebook" />
      <PlatformBadge platform="instagram" />
      <PlatformBadge platform="twitter" />
      <PlatformBadge platform="linkedin" />
      <PlatformBadge platform="youtube" />
      <PlatformBadge platform="tiktok" />
    </div>
  );
}
