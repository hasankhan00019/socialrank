import CompareInstitutions from '../../pages/CompareInstitutions';

export default function CompareInstitutionsExample() {
  return <CompareInstitutions />;
}
