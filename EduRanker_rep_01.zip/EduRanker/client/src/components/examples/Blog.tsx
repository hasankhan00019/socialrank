import Blog from '../../pages/Blog';

export default function BlogExample() {
  return <Blog />;
}
