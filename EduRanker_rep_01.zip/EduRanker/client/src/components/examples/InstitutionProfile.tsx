import InstitutionProfile from '../../pages/InstitutionProfile';

export default function InstitutionProfileExample() {
  return <InstitutionProfile />;
}
