import HomePage from '../../pages/HomePage';

export default function HomePageExample() {
  return <HomePage />;
}
