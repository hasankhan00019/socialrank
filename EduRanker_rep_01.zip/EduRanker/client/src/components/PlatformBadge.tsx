import { Badge } from "@/components/ui/badge";
import { Facebook, Instagram, Linkedin, Twitter, Youtube } from "lucide-react";
import { SiTiktok } from "react-icons/si";

export type Platform = "facebook" | "instagram" | "twitter" | "linkedin" | "youtube" | "tiktok";

interface PlatformBadgeProps {
  platform: Platform;
  size?: "sm" | "md";
}

const platformConfig = {
  facebook: { icon: Facebook, label: "Facebook", color: "text-[#1877F2]" },
  instagram: { icon: Instagram, label: "Instagram", color: "text-[#E4405F]" },
  twitter: { icon: Twitter, label: "X", color: "text-foreground" },
  linkedin: { icon: Linkedin, label: "LinkedIn", color: "text-[#0A66C2]" },
  youtube: { icon: Youtube, label: "YouTube", color: "text-[#FF0000]" },
  tiktok: { icon: SiTiktok, label: "TikTok", color: "text-foreground" },
};

export default function PlatformBadge({ platform, size = "md" }: PlatformBadgeProps) {
  const config = platformConfig[platform];
  const Icon = config.icon;
  const iconSize = size === "sm" ? "h-3 w-3" : "h-4 w-4";
  const textSize = size === "sm" ? "text-xs" : "text-sm";

  return (
    <Badge variant="secondary" className={`gap-1.5 ${textSize}`} data-testid={`badge-platform-${platform}`}>
      <Icon className={`${iconSize} ${config.color}`} />
      <span>{config.label}</span>
    </Badge>
  );
}
