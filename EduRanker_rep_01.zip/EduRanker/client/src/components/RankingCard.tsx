import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import TrendIndicator from "./TrendIndicator";
import { ExternalLink } from "lucide-react";
import { Link } from "wouter";

interface RankingCardProps {
  rank: number;
  institutionId: string;
  institutionName: string;
  country: string;
  score: number;
  followers: number;
  engagement: number;
  trend: number;
}

export default function RankingCard({
  rank,
  institutionId,
  institutionName,
  country,
  score,
  followers,
  engagement,
  trend,
}: RankingCardProps) {
  const getRankBadge = () => {
    if (rank === 1) return "bg-yellow-500/20 text-yellow-700 dark:text-yellow-400 border-yellow-500/30";
    if (rank === 2) return "bg-gray-400/20 text-gray-700 dark:text-gray-300 border-gray-400/30";
    if (rank === 3) return "bg-orange-600/20 text-orange-700 dark:text-orange-400 border-orange-600/30";
    return "";
  };

  return (
    <Card className="p-6 hover-elevate" data-testid={`card-ranking-${institutionId}`}>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0">
            {rank <= 3 ? (
              <Badge className={`h-10 w-10 items-center justify-center rounded-lg border text-lg font-bold ${getRankBadge()}`}>
                #{rank}
              </Badge>
            ) : (
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                <span className="font-mono text-sm font-semibold text-muted-foreground">#{rank}</span>
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-start gap-2">
              <h3 className="text-lg font-semibold leading-tight">{institutionName}</h3>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{country}</p>
            <div className="mt-3 flex flex-wrap items-center gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Score:</span>{" "}
                <span className="font-mono font-semibold">{score.toFixed(1)}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Followers:</span>{" "}
                <span className="font-mono font-semibold">{followers.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Engagement:</span>{" "}
                <span className="font-mono font-semibold">{engagement.toFixed(2)}%</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-3 sm:flex-shrink-0">
          <TrendIndicator value={trend} />
          <Link href={`/institution/${institutionId}`}>
            <a>
              <Button variant="outline" size="sm" data-testid={`button-view-${institutionId}`}>
                View Details
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </a>
          </Link>
        </div>
      </div>
    </Card>
  );
}
