import { Link } from "wouter";
import { Facebook, Instagram, Linkedin, Twitter, Youtube } from "lucide-react";
import { SiTiktok } from "react-icons/si";

export default function Footer() {
  return (
    <footer className="border-t bg-card">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary">
                <span className="font-mono text-lg font-bold text-primary-foreground">SL</span>
              </div>
              <span className="text-lg font-bold">SociaLearn Index</span>
            </div>
            <p className="text-sm text-muted-foreground">
              The global benchmark for digital influence in higher education.
            </p>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/rankings">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-rankings">
                    Rankings
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/methodology">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-methodology">
                    Methodology
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/blog">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-blog">
                    Insights
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold">Platforms Tracked</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Facebook</li>
              <li>Instagram</li>
              <li>X (Twitter)</li>
              <li>LinkedIn</li>
              <li>YouTube</li>
              <li>TikTok</li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold">Follow Platforms</h3>
            <div className="flex gap-3">
              <a href="#" className="text-muted-foreground hover:text-foreground" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground" aria-label="X">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground" aria-label="YouTube">
                <Youtube className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground" aria-label="TikTok">
                <SiTiktok className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 SociaLearn Index. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
