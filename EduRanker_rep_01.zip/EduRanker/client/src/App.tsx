import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HomePage from "@/pages/HomePage";
import RankingsHub from "@/pages/RankingsHub";
import InstitutionProfile from "@/pages/InstitutionProfile";
import CompareInstitutions from "@/pages/CompareInstitutions";
import Methodology from "@/pages/Methodology";
import Blog from "@/pages/Blog";
import BlogPost from "@/pages/BlogPost";
import AdminLayout from "@/pages/admin/AdminLayout";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import InstitutionsManager from "@/pages/admin/InstitutionsManager";
import RankingsControl from "@/pages/admin/RankingsControl";
import BlogManager from "@/pages/admin/BlogManager";
import NotFound from "@/pages/not-found";

function PublicRouter() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/rankings" component={RankingsHub} />
      <Route path="/institution/:id" component={InstitutionProfile} />
      <Route path="/compare" component={CompareInstitutions} />
      <Route path="/methodology" component={Methodology} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={BlogPost} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AdminRouter() {
  return (
    <AdminLayout>
      <Switch>
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin/institutions" component={InstitutionsManager} />
        <Route path="/admin/rankings" component={RankingsControl} />
        <Route path="/admin/blog" component={BlogManager} />
        <Route path="/admin/media">
          <div className="text-muted-foreground">Media Library - Coming Soon</div>
        </Route>
        <Route path="/admin/analytics">
          <div className="text-muted-foreground">Analytics - Coming Soon</div>
        </Route>
        <Route path="/admin/content">
          <div className="text-muted-foreground">Content Management - Coming Soon</div>
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AdminLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Switch>
          <Route path="/admin/:rest*">
            {() => (
              <>
                <AdminRouter />
                <Toaster />
              </>
            )}
          </Route>
          <Route path="/:rest*">
            {() => (
              <>
                <div className="flex min-h-screen flex-col">
                  <Header />
                  <main className="flex-1">
                    <PublicRouter />
                  </main>
                  <Footer />
                </div>
                <Toaster />
              </>
            )}
          </Route>
        </Switch>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
