import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import StatCard from "@/components/StatCard";
import { Building2, FileText, CheckCircle, TrendingUp } from "lucide-react";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: analytics } = useQuery({
    queryKey: ["/api/admin/analytics/overview"],
  });

  if (isLoading) {
    return <div className="flex min-h-screen items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="mb-2 text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your administrative panel</p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Institutions"
          value={analytics?.totalInstitutions?.toString() || "0"}
          icon={Building2}
        />
        <StatCard
          title="Verified Institutions"
          value={analytics?.institutionsVerified?.toString() || "0"}
          icon={CheckCircle}
        />
        <StatCard
          title="Published Posts"
          value={analytics?.totalPublishedPosts?.toString() || "0"}
          icon={FileText}
        />
        <StatCard title="Active Rankings" value="6" icon={TrendingUp} />
      </div>

      <Card className="p-6">
        <h2 className="mb-4 text-xl font-semibold">Quick Actions</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <a
            href="/admin/institutions"
            className="flex items-center gap-3 rounded-lg border p-4 hover-elevate overflow-visible"
          >
            <Building2 className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium">Manage Institutions</p>
              <p className="text-sm text-muted-foreground">Add or edit institutions</p>
            </div>
          </a>
          <a
            href="/admin/rankings"
            className="flex items-center gap-3 rounded-lg border p-4 hover-elevate overflow-visible"
          >
            <TrendingUp className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium">Update Rankings</p>
              <p className="text-sm text-muted-foreground">Configure algorithm weights</p>
            </div>
          </a>
          <a
            href="/admin/blog"
            className="flex items-center gap-3 rounded-lg border p-4 hover-elevate overflow-visible"
          >
            <FileText className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium">Create Blog Post</p>
              <p className="text-sm text-muted-foreground">Publish new insights</p>
            </div>
          </a>
        </div>
      </Card>
    </div>
  );
}
