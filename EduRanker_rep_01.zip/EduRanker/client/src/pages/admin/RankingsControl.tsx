import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import PlatformBadge from "@/components/PlatformBadge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";

const platforms = [
  { key: "linkedin", label: "LinkedIn", defaultWeight: 25 },
  { key: "facebook", label: "Facebook", defaultWeight: 20 },
  { key: "instagram", label: "Instagram", defaultWeight: 20 },
  { key: "youtube", label: "YouTube", defaultWeight: 15 },
  { key: "twitter", label: "X (Twitter)", defaultWeight: 15 },
  { key: "tiktok", label: "TikTok", defaultWeight: 5 },
];

export default function RankingsControl() {
  const { toast } = useToast();
  const [weights, setWeights] = useState<Record<string, number>>({});
  const [isInitialized, setIsInitialized] = useState(false);

  const { data: rankingWeights, isLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/ranking-weights"],
  });

  // Initialize weights once when data loads
  useEffect(() => {
    if (rankingWeights && !isInitialized) {
      const weightMap: Record<string, any> = {};
      rankingWeights.forEach((w) => {
        weightMap[w.platform] = w;
      });
      
      const initialWeights: Record<string, number> = {};
      platforms.forEach((p) => {
        initialWeights[p.key] = weightMap[p.key]?.weight || p.defaultWeight;
      });
      setWeights(initialWeights);
      setIsInitialized(true);
    }
  }, [rankingWeights, isInitialized]);

  const updateMutation = useMutation({
    mutationFn: (data: { platform: string; weight: number }) =>
      apiRequest("/api/admin/ranking-weights", {
        method: "POST",
        body: JSON.stringify({
          platform: data.platform,
          weight: data.weight,
          isActive: true,
        }),
        headers: { "Content-Type": "application/json" },
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ranking-weights"] });
      toast({ title: "Success", description: "Ranking weights updated successfully" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update ranking weights",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    // Save all weights
    platforms.forEach((platform) => {
      updateMutation.mutate({
        platform: platform.key,
        weight: weights[platform.key] || platform.defaultWeight,
      });
    });
  };

  const totalWeight = Object.values(weights).reduce((sum, w) => sum + w, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="mb-2 text-3xl font-bold tracking-tight">Ranking Control</h1>
        <p className="text-muted-foreground">
          Configure algorithm weights for the combined index ranking
        </p>
      </div>

      <Card className="p-6">
        <div className="mb-6">
          <h2 className="mb-2 text-xl font-semibold">Platform Weights</h2>
          <p className="text-sm text-muted-foreground">
            Adjust the weight of each platform in the combined index calculation. Total should
            equal 100%.
          </p>
        </div>

        <div className="space-y-6">
          {platforms.map((platform) => (
            <div key={platform.key} className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <PlatformBadge platform={platform.key as any} />
                </div>
                <span className="font-mono text-lg font-semibold">
                  {weights[platform.key] || platform.defaultWeight}%
                </span>
              </div>
              <Slider
                value={[weights[platform.key] || platform.defaultWeight]}
                onValueChange={([value]) =>
                  setWeights((prev) => ({ ...prev, [platform.key]: value }))
                }
                max={50}
                min={0}
                step={1}
                className="w-full"
                data-testid={`slider-${platform.key}`}
              />
            </div>
          ))}
        </div>

        <div className="mt-6 rounded-lg border bg-muted/50 p-4">
          <div className="flex items-center justify-between">
            <span className="font-medium">Total Weight:</span>
            <span
              className={`font-mono text-xl font-bold ${
                totalWeight === 100 ? "text-chart-2" : "text-destructive"
              }`}
            >
              {totalWeight}%
            </span>
          </div>
          {totalWeight !== 100 && (
            <p className="mt-2 text-sm text-destructive">
              Warning: Total weight must equal 100%
            </p>
          )}
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <Button
            variant="outline"
            onClick={() => {
              const resetWeights: Record<string, number> = {};
              platforms.forEach((p) => {
                resetWeights[p.key] = p.defaultWeight;
              });
              setWeights(resetWeights);
            }}
          >
            Reset to Defaults
          </Button>
          <Button
            onClick={handleSave}
            disabled={totalWeight !== 100 || updateMutation.isPending}
            data-testid="button-save-weights"
          >
            {updateMutation.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </Card>

      <Card className="p-6">
        <h2 className="mb-4 text-xl font-semibold">Methodology</h2>
        <div className="space-y-3 text-sm text-muted-foreground">
          <p>
            <strong className="text-foreground">Platform Score Formula:</strong>
            <br />
            Follower Score = (Institution Followers / Max Followers) × 50
            <br />
            Engagement Score = (Avg Engagement / Max Engagement) × 50
            <br />
            Platform Score = Follower Score + Engagement Score
          </p>
          <p>
            <strong className="text-foreground">Combined Index:</strong>
            <br />
            Total Score = Σ (Platform Score × Platform Weight / 100)
          </p>
        </div>
      </Card>
    </div>
  );
}
