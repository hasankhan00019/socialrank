import { Card } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

export default function Methodology() {
  return (
    <div className="min-h-screen bg-background py-8">
      <div className="mx-auto max-w-4xl px-6">
        <div className="mb-12 text-center">
          <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">
            Our Methodology
          </h1>
          <p className="text-xl text-muted-foreground">
            Transparent, data-driven approach to ranking university social media influence
          </p>
        </div>

        {/* Overview */}
        <Card className="mb-8 p-8">
          <h2 className="mb-4 text-2xl font-semibold">Ranking Formula Overview</h2>
          <p className="mb-6 text-muted-foreground">
            Our comprehensive ranking system evaluates universities across six major social media
            platforms. Each platform score is calculated using a combination of follower count and
            engagement metrics, then weighted to produce a combined index score.
          </p>
          <div className="rounded-lg bg-muted p-6 font-mono text-sm">
            <div className="mb-4">
              <strong>Platform Score Formula:</strong>
              <br />
              Follower Score = (Institution Followers / Max Followers) × 50
              <br />
              Engagement Score = (Avg Engagement / Max Engagement) × 50
              <br />
              Platform Score = Follower Score + Engagement Score
            </div>
            <div>
              <strong>Combined Index:</strong>
              <br />
              Total Score = Σ (Platform Score × Platform Weight)
            </div>
          </div>
        </Card>

        {/* Platform Weights */}
        <Card className="mb-8 p-8">
          <h2 className="mb-4 text-2xl font-semibold">Platform Weights</h2>
          <p className="mb-6 text-muted-foreground">
            Each platform is assigned a weight based on its relevance to higher education and
            academic institutions.
          </p>
          <div className="space-y-3">
            {[
              { platform: "LinkedIn", weight: 25, rationale: "Professional networking and recruitment" },
              { platform: "Facebook", weight: 20, rationale: "Broad reach and community building" },
              { platform: "Instagram", weight: 20, rationale: "Visual storytelling and campus life" },
              { platform: "YouTube", weight: 15, rationale: "Educational content and lectures" },
              { platform: "X (Twitter)", weight: 15, rationale: "Real-time updates and thought leadership" },
              { platform: "TikTok", weight: 5, rationale: "Emerging platform for student engagement" },
            ].map((item) => (
              <div
                key={item.platform}
                className="flex items-center justify-between rounded-lg border p-4"
              >
                <div>
                  <p className="font-semibold">{item.platform}</p>
                  <p className="text-sm text-muted-foreground">{item.rationale}</p>
                </div>
                <Badge variant="secondary" className="font-mono text-base">
                  {item.weight}%
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Data Collection */}
        <Card className="mb-8 p-8">
          <h2 className="mb-4 text-2xl font-semibold">Data Collection Process</h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="frequency">
              <AccordionTrigger>Update Frequency</AccordionTrigger>
              <AccordionContent>
                <p className="text-muted-foreground">
                  Rankings are updated monthly to reflect the latest social media metrics. Data is
                  collected during the first week of each month and rankings are published by the
                  15th.
                </p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="sources">
              <AccordionTrigger>Data Sources</AccordionTrigger>
              <AccordionContent>
                <p className="text-muted-foreground">
                  We collect data from official, verified institutional accounts only. Metrics
                  include follower counts, post engagement (likes, shares, comments), and
                  interaction rates across all tracked platforms.
                </p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="verification">
              <AccordionTrigger>Account Verification</AccordionTrigger>
              <AccordionContent>
                <p className="text-muted-foreground">
                  Only officially verified university accounts are included in our rankings. We
                  verify accounts through platform verification badges and cross-reference with
                  official university websites.
                </p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="engagement">
              <AccordionTrigger>Engagement Calculation</AccordionTrigger>
              <AccordionContent>
                <p className="text-muted-foreground">
                  Engagement rate is calculated as (Total Interactions / Total Followers) × 100.
                  Interactions include likes, comments, shares, and video views. We analyze the
                  most recent 30 posts per platform for accuracy.
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>

        {/* Quality Standards */}
        <Card className="mb-8 p-8">
          <h2 className="mb-4 text-2xl font-semibold">Quality Standards</h2>
          <ul className="space-y-3 text-muted-foreground">
            <li className="flex gap-3">
              <span className="text-chart-2">✓</span>
              <span>All data is collected from publicly available, official sources</span>
            </li>
            <li className="flex gap-3">
              <span className="text-chart-2">✓</span>
              <span>Rankings are calculated using consistent, automated algorithms</span>
            </li>
            <li className="flex gap-3">
              <span className="text-chart-2">✓</span>
              <span>Historical data is preserved for trend analysis</span>
            </li>
            <li className="flex gap-3">
              <span className="text-chart-2">✓</span>
              <span>Methodology is regularly reviewed and updated</span>
            </li>
            <li className="flex gap-3">
              <span className="text-chart-2">✓</span>
              <span>No paid placements or sponsored rankings</span>
            </li>
          </ul>
        </Card>

        {/* Transparency Note */}
        <Card className="border-primary/30 bg-primary/5 p-8">
          <h3 className="mb-2 text-lg font-semibold">Our Commitment to Transparency</h3>
          <p className="text-muted-foreground">
            We believe in complete transparency in our ranking methodology. All formulas, weights,
            and data sources are publicly disclosed. Institutions can request their raw data and
            detailed scoring breakdown at any time.
          </p>
        </Card>
      </div>
    </div>
  );
}
