import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User, Share2, Twitter, Linkedin, Facebook } from "lucide-react";
import { Link } from "wouter";

//todo: remove mock functionality
const mockPost = {
  slug: "social-media-trends-2025",
  title: "Social Media Trends Shaping Higher Education in 2025",
  author: "Dr. Sarah Chen",
  publishedAt: "2025-01-15",
  readTime: "5 min read",
  tags: ["Trends", "Social Media", "Higher Education"],
  content: `
    <h2>The Digital Transformation of Higher Education</h2>
    <p>Universities worldwide are experiencing a profound shift in how they engage with students, alumni, and the broader community through social media platforms. As we move through 2025, several key trends are reshaping the landscape of digital engagement in higher education.</p>
    
    <h3>1. Short-Form Video Dominance</h3>
    <p>Short-form video content continues to dominate social media engagement. Platforms like TikTok and Instagram Reels have become essential tools for universities to showcase campus life, share student stories, and humanize their brand. The most successful institutions are creating authentic, student-led content that resonates with Gen Z audiences.</p>
    
    <h3>2. LinkedIn's Growing Importance</h3>
    <p>LinkedIn has evolved from a purely professional networking platform to a crucial channel for university recruitment and alumni engagement. Universities are using LinkedIn to highlight career outcomes, share thought leadership content, and connect students with potential employers.</p>
    
    <h3>3. Authenticity Over Polish</h3>
    <p>Today's audiences value authenticity over highly produced content. Universities are finding success with behind-the-scenes content, student takeovers, and real stories from campus community members. This shift requires institutions to embrace a more transparent and genuine communication style.</p>
    
    <h3>4. Community Building and Engagement</h3>
    <p>The focus is shifting from broadcasting to building communities. Universities are creating dedicated spaces for alumni, prospective students, and current students to connect, share experiences, and support each other. This community-first approach leads to higher engagement rates and stronger brand loyalty.</p>
    
    <h3>5. Data-Driven Strategy</h3>
    <p>Sophisticated analytics tools are enabling universities to make more informed decisions about their social media strategy. Understanding engagement patterns, audience demographics, and content performance allows institutions to optimize their approach and demonstrate ROI.</p>
    
    <h2>Looking Ahead</h2>
    <p>As social media platforms continue to evolve, universities must remain agile and responsive to emerging trends. The institutions that will thrive are those that prioritize authentic engagement, embrace new platforms early, and maintain a student-centered approach to their digital presence.</p>
    
    <p>The future of higher education marketing lies in building genuine connections through social media—connections that extend beyond the application process and continue throughout a student's academic journey and beyond.</p>
  `,
};

const relatedPosts = [
  {
    slug: "instagram-engagement-strategies",
    title: "Top 10 Instagram Engagement Strategies for Universities",
    readTime: "7 min read",
  },
  {
    slug: "tiktok-campus-life",
    title: "TikTok's Rising Influence on Campus Life Storytelling",
    readTime: "4 min read",
  },
];

export default function BlogPost() {
  const handleShare = (platform: string) => {
    console.log(`Share to ${platform} triggered`);
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="mx-auto max-w-4xl px-6">
        {/* Back Button */}
        <div className="mb-8">
          <Link href="/blog">
            <a>
              <Button variant="ghost" data-testid="button-back-to-blog">
                ← Back to Insights
              </Button>
            </a>
          </Link>
        </div>

        {/* Article Header */}
        <article>
          <header className="mb-8">
            <div className="mb-4 flex flex-wrap gap-2">
              {mockPost.tags.map((tag) => (
                <Badge key={tag} variant="secondary">
                  {tag}
                </Badge>
              ))}
            </div>
            <h1 className="mb-6 text-4xl font-bold tracking-tight md:text-5xl">
              {mockPost.title}
            </h1>
            <div className="flex flex-wrap items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span className="font-medium">{mockPost.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{new Date(mockPost.publishedAt).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{mockPost.readTime}</span>
              </div>
            </div>
          </header>

          {/* Featured Image */}
          <div className="mb-8 h-96 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5"></div>

          {/* Share Buttons */}
          <Card className="mb-8 p-6">
            <div className="flex flex-wrap items-center gap-4">
              <span className="font-medium">Share this article:</span>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleShare("twitter")}
                  data-testid="button-share-twitter"
                >
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleShare("linkedin")}
                  data-testid="button-share-linkedin"
                >
                  <Linkedin className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleShare("facebook")}
                  data-testid="button-share-facebook"
                >
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleShare("copy")}
                  data-testid="button-share-copy"
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Copy Link
                </Button>
              </div>
            </div>
          </Card>

          {/* Article Content */}
          <div
            className="prose prose-lg max-w-none dark:prose-invert"
            dangerouslySetInnerHTML={{ __html: mockPost.content }}
          />

          {/* Author Bio */}
          <Card className="my-12 p-6">
            <div className="flex items-start gap-4">
              <div className="flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-full bg-primary/10">
                <span className="text-2xl font-bold text-primary">
                  {mockPost.author.split(" ").map((n) => n[0]).join("")}
                </span>
              </div>
              <div>
                <h3 className="mb-1 text-lg font-semibold">{mockPost.author}</h3>
                <p className="text-sm text-muted-foreground">
                  Senior Analyst at SociaLearn Index, specializing in social media trends and
                  higher education marketing strategies.
                </p>
              </div>
            </div>
          </Card>

          {/* Related Articles */}
          <div className="border-t pt-12">
            <h2 className="mb-6 text-2xl font-semibold">Related Articles</h2>
            <div className="grid gap-6 md:grid-cols-2">
              {relatedPosts.map((post) => (
                <Card key={post.slug} className="p-6 hover-elevate">
                  <Link href={`/blog/${post.slug}`}>
                    <a>
                      <h3 className="mb-2 text-lg font-semibold hover:text-primary">
                        {post.title}
                      </h3>
                    </a>
                  </Link>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>{post.readTime}</span>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </article>
      </div>
    </div>
  );
}
