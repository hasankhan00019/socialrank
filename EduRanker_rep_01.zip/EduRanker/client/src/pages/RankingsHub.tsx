import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import RankingCard from "@/components/RankingCard";
import PlatformBadge, { Platform } from "@/components/PlatformBadge";
import { Search, Download } from "lucide-react";

//todo: remove mock functionality
const mockRankings = [
  {
    rank: 1,
    institutionId: "harvard",
    institutionName: "Harvard University",
    country: "United States",
    score: 95.8,
    followers: 2500000,
    engagement: 4.2,
    trend: 8.5,
  },
  {
    rank: 2,
    institutionId: "stanford",
    institutionName: "Stanford University",
    country: "United States",
    score: 92.3,
    followers: 2100000,
    engagement: 3.9,
    trend: 5.2,
  },
  {
    rank: 3,
    institutionId: "mit",
    institutionName: "MIT",
    country: "United States",
    score: 91.7,
    followers: 1950000,
    engagement: 4.5,
    trend: 12.3,
  },
  {
    rank: 4,
    institutionId: "oxford",
    institutionName: "University of Oxford",
    country: "United Kingdom",
    score: 89.2,
    followers: 1850000,
    engagement: 3.7,
    trend: -1.5,
  },
  {
    rank: 5,
    institutionId: "cambridge",
    institutionName: "University of Cambridge",
    country: "United Kingdom",
    score: 87.9,
    followers: 1720000,
    engagement: 3.8,
    trend: 2.8,
  },
  {
    rank: 6,
    institutionId: "yale",
    institutionName: "Yale University",
    country: "United States",
    score: 85.4,
    followers: 1650000,
    engagement: 3.6,
    trend: 3.1,
  },
];

export default function RankingsHub() {
  const [searchTerm, setSearchTerm] = useState("");
  const [country, setCountry] = useState("all");
  const [institutionType, setInstitutionType] = useState("all");

  const handleExport = () => {
    console.log("Export data triggered");
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2 text-4xl font-bold tracking-tight">University Rankings</h1>
          <p className="text-lg text-muted-foreground">
            Comprehensive rankings based on social media influence and engagement
          </p>
        </div>

        {/* Filters */}
        <Card className="mb-8 p-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search institutions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-institutions"
                />
              </div>
            </div>
            <Select value={country} onValueChange={setCountry}>
              <SelectTrigger data-testid="select-country">
                <SelectValue placeholder="All Countries" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Countries</SelectItem>
                <SelectItem value="us">United States</SelectItem>
                <SelectItem value="uk">United Kingdom</SelectItem>
                <SelectItem value="ca">Canada</SelectItem>
              </SelectContent>
            </Select>
            <Select value={institutionType} onValueChange={setInstitutionType}>
              <SelectTrigger data-testid="select-type">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="public">Public</SelectItem>
                <SelectItem value="private">Private</SelectItem>
                <SelectItem value="research">Research</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>

        {/* Platform Tabs */}
        <Tabs defaultValue="combined" className="mb-8">
          <div className="mb-4 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
            <TabsList>
              <TabsTrigger value="combined" data-testid="tab-combined">
                Combined Index
              </TabsTrigger>
              <TabsTrigger value="facebook" data-testid="tab-facebook">
                Facebook
              </TabsTrigger>
              <TabsTrigger value="instagram" data-testid="tab-instagram">
                Instagram
              </TabsTrigger>
              <TabsTrigger value="twitter" data-testid="tab-twitter">
                X
              </TabsTrigger>
              <TabsTrigger value="linkedin" data-testid="tab-linkedin">
                LinkedIn
              </TabsTrigger>
              <TabsTrigger value="youtube" data-testid="tab-youtube">
                YouTube
              </TabsTrigger>
              <TabsTrigger value="tiktok" data-testid="tab-tiktok">
                TikTok
              </TabsTrigger>
            </TabsList>
            <Button variant="outline" onClick={handleExport} data-testid="button-export">
              <Download className="mr-2 h-4 w-4" />
              Export Data
            </Button>
          </div>

          <TabsContent value="combined">
            <div className="space-y-4">
              {mockRankings.map((institution) => (
                <RankingCard key={institution.institutionId} {...institution} />
              ))}
            </div>
          </TabsContent>

          {(["facebook", "instagram", "twitter", "linkedin", "youtube", "tiktok"] as Platform[]).map((platform) => (
            <TabsContent key={platform} value={platform}>
              <div className="mb-4">
                <PlatformBadge platform={platform} />
              </div>
              <div className="space-y-4">
                {mockRankings.map((institution) => (
                  <RankingCard key={institution.institutionId} {...institution} />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}
