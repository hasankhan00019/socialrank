import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import StatCard from "@/components/StatCard";
import RankingCard from "@/components/RankingCard";
import { Building2, TrendingUp, Users, Globe } from "lucide-react";
import { Link } from "wouter";
import heroImage from "@assets/generated_images/University_campus_hero_background_5e3826e7.png";

//todo: remove mock functionality
const mockTopInstitutions = [
  {
    rank: 1,
    institutionId: "harvard",
    institutionName: "Harvard University",
    country: "United States",
    score: 95.8,
    followers: 2500000,
    engagement: 4.2,
    trend: 8.5,
  },
  {
    rank: 2,
    institutionId: "stanford",
    institutionName: "Stanford University",
    country: "United States",
    score: 92.3,
    followers: 2100000,
    engagement: 3.9,
    trend: 5.2,
  },
  {
    rank: 3,
    institutionId: "mit",
    institutionName: "MIT",
    country: "United States",
    score: 91.7,
    followers: 1950000,
    engagement: 4.5,
    trend: 12.3,
  },
  {
    rank: 4,
    institutionId: "oxford",
    institutionName: "University of Oxford",
    country: "United Kingdom",
    score: 89.2,
    followers: 1850000,
    engagement: 3.7,
    trend: -1.5,
  },
  {
    rank: 5,
    institutionId: "cambridge",
    institutionName: "University of Cambridge",
    country: "United Kingdom",
    score: 87.9,
    followers: 1720000,
    engagement: 3.8,
    trend: 2.8,
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section
        className="relative flex min-h-[600px] items-center justify-center overflow-hidden bg-gradient-to-br from-primary/5 via-background to-background"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0.7)), url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="relative z-10 mx-auto max-w-4xl px-6 py-20 text-center">
          <h1 className="mb-6 text-5xl font-bold tracking-tight text-white md:text-6xl lg:text-7xl">
            The Global Benchmark for Digital Influence in Higher Education
          </h1>
          <p className="mb-8 text-xl text-white/90 md:text-2xl">
            Ranking universities based on social media presence, engagement, and influence across
            multiple platforms.
          </p>
          <div className="flex flex-col justify-center gap-4 sm:flex-row">
            <Link href="/rankings">
              <a>
                <Button size="lg" variant="default" className="bg-primary text-primary-foreground border border-primary-border" data-testid="button-explore-rankings">
                  Explore Rankings
                </Button>
              </a>
            </Link>
            <Link href="/compare">
              <a>
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-background/20 backdrop-blur-sm border-white/30 text-white hover:bg-background/30"
                  data-testid="button-compare-institutions"
                >
                  Compare Institutions
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Global Stats Section */}
      <section className="bg-background py-16">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl">
              Global Statistics
            </h2>
            <p className="text-lg text-muted-foreground">
              Tracking digital influence across the world's leading institutions
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              title="Institutions Tracked"
              value="1,247"
              icon={Building2}
              trend={{ value: "12% this month", positive: true }}
            />
            <StatCard
              title="Total Followers"
              value="2.4B"
              icon={Users}
              trend={{ value: "8% this month", positive: true }}
            />
            <StatCard
              title="Avg. Engagement Rate"
              value="3.8%"
              icon={TrendingUp}
              trend={{ value: "0.4% this month", positive: true }}
            />
            <StatCard
              title="Countries Covered"
              value="142"
              icon={Globe}
            />
          </div>
        </div>
      </section>

      {/* Top 5 Institutions */}
      <section className="bg-card py-16">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-12 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
            <div>
              <h2 className="mb-2 text-3xl font-bold tracking-tight md:text-4xl">
                Top 5 Institutions
              </h2>
              <p className="text-lg text-muted-foreground">
                Leading universities in global social media influence
              </p>
            </div>
            <Link href="/rankings">
              <a>
                <Button variant="outline" data-testid="button-view-all-rankings">
                  View All Rankings
                </Button>
              </a>
            </Link>
          </div>
          <div className="space-y-4">
            {mockTopInstitutions.map((institution) => (
              <RankingCard key={institution.institutionId} {...institution} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl">
            Transparent. Data-Driven. Insightful.
          </h2>
          <p className="mb-8 text-lg text-muted-foreground">
            Learn how we calculate our rankings and what makes our methodology unique
          </p>
          <Link href="/methodology">
            <a>
              <Button size="lg" variant="default" data-testid="button-learn-methodology">
                Learn Our Methodology
              </Button>
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
