import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformBadge from "@/components/PlatformBadge";
import TrendIndicator from "@/components/TrendIndicator";
import { ExternalLink, Share2 } from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Link } from "wouter";

//todo: remove mock functionality
const mockInstitution = {
  id: "harvard",
  name: "Harvard University",
  country: "United States",
  type: "Private Research University",
  website: "https://www.harvard.edu",
  rank: 1,
  score: 95.8,
  totalFollowers: 2500000,
  avgEngagement: 4.2,
  trend: 8.5,
};

const mockPlatformData = [
  { platform: "Facebook", followers: 850000, engagement: 3.8, score: 92.5 },
  { platform: "Instagram", followers: 650000, engagement: 5.2, score: 95.1 },
  { platform: "Twitter", followers: 420000, engagement: 4.5, score: 88.3 },
  { platform: "LinkedIn", followers: 280000, engagement: 3.1, score: 85.7 },
  { platform: "YouTube", followers: 220000, engagement: 4.8, score: 90.2 },
  { platform: "TikTok", followers: 80000, engagement: 6.5, score: 78.9 },
];

const mockHistoricalData = [
  { month: "Jul", followers: 2200000, engagement: 3.8, score: 89.2 },
  { month: "Aug", followers: 2280000, engagement: 3.9, score: 91.5 },
  { month: "Sep", followers: 2350000, engagement: 4.0, score: 93.1 },
  { month: "Oct", followers: 2410000, engagement: 4.1, score: 94.3 },
  { month: "Nov", followers: 2460000, engagement: 4.15, score: 95.0 },
  { month: "Dec", followers: 2500000, engagement: 4.2, score: 95.8 },
];

export default function InstitutionProfile() {
  return (
    <div className="min-h-screen bg-background py-8">
      <div className="mx-auto max-w-7xl px-6">
        {/* Header */}
        <Card className="mb-8 p-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div className="flex-1">
              <div className="mb-4 flex items-start gap-4">
                <div className="flex h-20 w-20 flex-shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <span className="text-3xl font-bold text-primary">H</span>
                </div>
                <div className="flex-1">
                  <div className="mb-2 flex items-center gap-2">
                    <h1 className="text-3xl font-bold tracking-tight">{mockInstitution.name}</h1>
                    <Badge className="bg-chart-2/20 text-chart-2 border-chart-2/30">Verified</Badge>
                  </div>
                  <p className="mb-2 text-lg text-muted-foreground">
                    {mockInstitution.country} • {mockInstitution.type}
                  </p>
                  <div className="flex flex-wrap items-center gap-3">
                    <Badge variant="secondary" className="text-lg font-bold">
                      Rank #{mockInstitution.rank}
                    </Badge>
                    <TrendIndicator value={mockInstitution.trend} />
                  </div>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-6 sm:grid-cols-4">
                <div>
                  <p className="text-sm text-muted-foreground">Overall Score</p>
                  <p className="mt-1 font-mono text-2xl font-bold">{mockInstitution.score}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Followers</p>
                  <p className="mt-1 font-mono text-2xl font-bold">
                    {(mockInstitution.totalFollowers / 1000000).toFixed(1)}M
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Engagement</p>
                  <p className="mt-1 font-mono text-2xl font-bold">
                    {mockInstitution.avgEngagement}%
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">6-Month Growth</p>
                  <p className="mt-1 font-mono text-2xl font-bold text-chart-2">+{mockInstitution.trend}%</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Link href="/compare">
                <a>
                  <Button variant="default" className="w-full lg:w-auto" data-testid="button-compare">
                    Compare Institution
                  </Button>
                </a>
              </Link>
              <Button variant="outline" data-testid="button-share">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
              <Button variant="outline" asChild>
                <a href={mockInstitution.website} target="_blank" rel="noopener noreferrer" data-testid="button-website">
                  Visit Website
                  <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>
          </div>
        </Card>

        {/* Social Media Links */}
        <Card className="mb-8 p-6">
          <h2 className="mb-4 text-lg font-semibold">Official Social Media Accounts</h2>
          <div className="flex flex-wrap gap-2">
            <PlatformBadge platform="facebook" />
            <PlatformBadge platform="instagram" />
            <PlatformBadge platform="twitter" />
            <PlatformBadge platform="linkedin" />
            <PlatformBadge platform="youtube" />
            <PlatformBadge platform="tiktok" />
          </div>
        </Card>

        {/* Platform Breakdown */}
        <Card className="mb-8 p-6">
          <h2 className="mb-6 text-2xl font-semibold">Platform Performance</h2>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={mockPlatformData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="platform" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "6px",
                }}
              />
              <Legend />
              <Bar dataKey="followers" fill="hsl(var(--chart-1))" name="Followers (K)" />
              <Bar dataKey="score" fill="hsl(var(--chart-2))" name="Score" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Historical Charts */}
        <Tabs defaultValue="6month" className="mb-8">
          <TabsList>
            <TabsTrigger value="6month" data-testid="tab-6month">
              6 Months
            </TabsTrigger>
            <TabsTrigger value="1year" data-testid="tab-1year">
              1 Year
            </TabsTrigger>
          </TabsList>

          <TabsContent value="6month">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="p-6">
                <h3 className="mb-4 text-lg font-semibold">Follower Growth</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={mockHistoricalData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="followers"
                      stroke="hsl(var(--chart-1))"
                      fill="hsl(var(--chart-1))"
                      fillOpacity={0.2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </Card>

              <Card className="p-6">
                <h3 className="mb-4 text-lg font-semibold">Overall Score Trend</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={mockHistoricalData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" domain={[85, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="score"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={3}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="1year">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="p-6">
                <h3 className="mb-4 text-lg font-semibold">Follower Growth (1 Year)</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={[...mockHistoricalData, ...mockHistoricalData]}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="followers"
                      stroke="hsl(var(--chart-1))"
                      fill="hsl(var(--chart-1))"
                      fillOpacity={0.2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </Card>

              <Card className="p-6">
                <h3 className="mb-4 text-lg font-semibold">Overall Score Trend (1 Year)</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={[...mockHistoricalData, ...mockHistoricalData]}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" domain={[85, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="score"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={3}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
