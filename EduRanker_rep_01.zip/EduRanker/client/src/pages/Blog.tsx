import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Calendar, Clock, User, Search } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

//todo: remove mock functionality
const mockBlogPosts = [
  {
    id: "1",
    slug: "social-media-trends-2025",
    title: "Social Media Trends Shaping Higher Education in 2025",
    excerpt: "Discover how universities are leveraging emerging platforms and strategies to connect with prospective students and alumni.",
    author: "Dr. Sarah Chen",
    publishedAt: "2025-01-15",
    readTime: "5 min read",
    tags: ["Trends", "Social Media", "Higher Education"],
    featured: true,
  },
  {
    id: "2",
    slug: "instagram-engagement-strategies",
    title: "Top 10 Instagram Engagement Strategies for Universities",
    excerpt: "Learn the proven tactics that top-ranked institutions use to boost their Instagram presence and engage with their audience.",
    author: "Michael Rodriguez",
    publishedAt: "2025-01-12",
    readTime: "7 min read",
    tags: ["Instagram", "Strategy", "Engagement"],
    featured: false,
  },
  {
    id: "3",
    slug: "linkedin-recruitment-impact",
    title: "How LinkedIn is Revolutionizing University Recruitment",
    excerpt: "Explore the growing importance of LinkedIn in connecting universities with prospective students and employers.",
    author: "Emma Thompson",
    publishedAt: "2025-01-08",
    readTime: "6 min read",
    tags: ["LinkedIn", "Recruitment", "Networking"],
    featured: false,
  },
  {
    id: "4",
    slug: "tiktok-campus-life",
    title: "TikTok's Rising Influence on Campus Life Storytelling",
    excerpt: "Why universities are turning to TikTok to showcase authentic student experiences and campus culture.",
    author: "Dr. Sarah Chen",
    publishedAt: "2025-01-05",
    readTime: "4 min read",
    tags: ["TikTok", "Campus Life", "Storytelling"],
    featured: false,
  },
  {
    id: "5",
    slug: "engagement-metrics-guide",
    title: "Understanding Engagement Metrics: A Complete Guide",
    excerpt: "Deep dive into the key performance indicators that matter most for university social media success.",
    author: "James Park",
    publishedAt: "2025-01-02",
    readTime: "8 min read",
    tags: ["Analytics", "Metrics", "Guide"],
    featured: false,
  },
  {
    id: "6",
    slug: "youtube-educational-content",
    title: "The Power of YouTube for Educational Content Marketing",
    excerpt: "How universities are using YouTube to share lectures, campus tours, and build their brand.",
    author: "Emma Thompson",
    publishedAt: "2024-12-28",
    readTime: "6 min read",
    tags: ["YouTube", "Content Marketing", "Education"],
    featured: false,
  },
];

export default function Blog() {
  const [searchTerm, setSearchTerm] = useState("");

  const featuredPost = mockBlogPosts.find((post) => post.featured);
  const regularPosts = mockBlogPosts.filter((post) => !post.featured);

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2 text-4xl font-bold tracking-tight">Insights & Analysis</h1>
          <p className="text-lg text-muted-foreground">
            Expert perspectives on social media trends in higher education
          </p>
        </div>

        {/* Search */}
        <Card className="mb-8 p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-blog"
            />
          </div>
        </Card>

        {/* Featured Post */}
        {featuredPost && (
          <Card className="mb-12 overflow-hidden hover-elevate" data-testid="card-featured-post">
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="h-64 bg-gradient-to-br from-primary/20 to-primary/5 lg:h-auto"></div>
              <div className="p-8">
                <Badge className="mb-4">Featured</Badge>
                <Link href={`/blog/${featuredPost.slug}`}>
                  <a>
                    <h2 className="mb-4 text-3xl font-bold tracking-tight hover:text-primary">
                      {featuredPost.title}
                    </h2>
                  </a>
                </Link>
                <p className="mb-6 text-lg text-muted-foreground">{featuredPost.excerpt}</p>
                <div className="mb-6 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <User className="h-4 w-4" />
                    <span>{featuredPost.author}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-4 w-4" />
                    <span>{new Date(featuredPost.publishedAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4" />
                    <span>{featuredPost.readTime}</span>
                  </div>
                </div>
                <div className="mb-6 flex flex-wrap gap-2">
                  {featuredPost.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <Link href={`/blog/${featuredPost.slug}`}>
                  <a>
                    <Button data-testid="button-read-featured">Read Article</Button>
                  </a>
                </Link>
              </div>
            </div>
          </Card>
        )}

        {/* Recent Posts Grid */}
        <div className="mb-8">
          <h2 className="mb-6 text-2xl font-semibold">Recent Articles</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {regularPosts.map((post) => (
              <Card
                key={post.id}
                className="flex flex-col overflow-hidden hover-elevate"
                data-testid={`card-post-${post.slug}`}
              >
                <div className="h-48 bg-gradient-to-br from-primary/10 to-primary/5"></div>
                <div className="flex flex-1 flex-col p-6">
                  <div className="mb-3 flex flex-wrap gap-2">
                    {post.tags.slice(0, 2).map((tag) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <Link href={`/blog/${post.slug}`}>
                    <a>
                      <h3 className="mb-3 text-xl font-semibold leading-tight hover:text-primary">
                        {post.title}
                      </h3>
                    </a>
                  </Link>
                  <p className="mb-4 flex-1 text-sm text-muted-foreground">{post.excerpt}</p>
                  <div className="flex flex-col gap-3 border-t pt-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <User className="h-4 w-4" />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
