import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import PlatformBadge from "@/components/PlatformBadge";
import TrendIndicator from "@/components/TrendIndicator";
import { Badge } from "@/components/ui/badge";

//todo: remove mock functionality
const mockInstitutions = [
  {
    id: "harvard",
    name: "Harvard University",
    country: "United States",
    rank: 1,
    score: 95.8,
    followers: 2500000,
    engagement: 4.2,
    trend: 8.5,
    platforms: {
      facebook: { followers: 850000, engagement: 3.8 },
      instagram: { followers: 650000, engagement: 5.2 },
      twitter: { followers: 420000, engagement: 4.5 },
      linkedin: { followers: 280000, engagement: 3.1 },
      youtube: { followers: 220000, engagement: 4.8 },
      tiktok: { followers: 80000, engagement: 6.5 },
    },
  },
  {
    id: "stanford",
    name: "Stanford University",
    country: "United States",
    rank: 2,
    score: 92.3,
    followers: 2100000,
    engagement: 3.9,
    trend: 5.2,
    platforms: {
      facebook: { followers: 720000, engagement: 3.5 },
      instagram: { followers: 580000, engagement: 4.8 },
      twitter: { followers: 390000, engagement: 4.2 },
      linkedin: { followers: 240000, engagement: 2.9 },
      youtube: { followers: 140000, engagement: 4.5 },
      tiktok: { followers: 30000, engagement: 5.8 },
    },
  },
  {
    id: "mit",
    name: "MIT",
    country: "United States",
    rank: 3,
    score: 91.7,
    followers: 1950000,
    engagement: 4.5,
    trend: 12.3,
    platforms: {
      facebook: { followers: 680000, engagement: 4.2 },
      instagram: { followers: 520000, engagement: 5.5 },
      twitter: { followers: 410000, engagement: 4.8 },
      linkedin: { followers: 220000, engagement: 3.3 },
      youtube: { followers: 100000, engagement: 5.2 },
      tiktok: { followers: 20000, engagement: 6.8 },
    },
  },
];

export default function CompareInstitutions() {
  const [institution1, setInstitution1] = useState("harvard");
  const [institution2, setInstitution2] = useState("stanford");

  const inst1 = mockInstitutions.find((i) => i.id === institution1)!;
  const inst2 = mockInstitutions.find((i) => i.id === institution2)!;

  const ComparisonRow = ({ label, value1, value2, isNumeric = false }: any) => {
    const better = isNumeric ? (value1 > value2 ? 1 : value1 < value2 ? 2 : 0) : 0;
    return (
      <div className="grid grid-cols-3 gap-4 border-b py-4 last:border-0">
        <div className={`text-center ${better === 1 ? "font-semibold text-chart-2" : ""}`}>
          {value1}
        </div>
        <div className="text-center font-medium text-muted-foreground">{label}</div>
        <div className={`text-center ${better === 2 ? "font-semibold text-chart-2" : ""}`}>
          {value2}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-8">
          <h1 className="mb-2 text-4xl font-bold tracking-tight">Compare Institutions</h1>
          <p className="text-lg text-muted-foreground">
            Side-by-side comparison of social media performance
          </p>
        </div>

        {/* Institution Selectors */}
        <Card className="mb-8 p-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium">Institution 1</label>
              <Select value={institution1} onValueChange={setInstitution1}>
                <SelectTrigger data-testid="select-institution-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockInstitutions.map((inst) => (
                    <SelectItem key={inst.id} value={inst.id}>
                      {inst.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="mb-2 block text-sm font-medium">Institution 2</label>
              <Select value={institution2} onValueChange={setInstitution2}>
                <SelectTrigger data-testid="select-institution-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockInstitutions.map((inst) => (
                    <SelectItem key={inst.id} value={inst.id}>
                      {inst.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Comparison Table */}
        <Card className="p-6">
          <div className="mb-6 grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="mb-3 flex h-16 w-16 mx-auto items-center justify-center rounded-lg bg-primary/10">
                <span className="text-2xl font-bold text-primary">{inst1.name[0]}</span>
              </div>
              <h3 className="mb-1 text-lg font-semibold">{inst1.name}</h3>
              <p className="text-sm text-muted-foreground">{inst1.country}</p>
              <Badge variant="secondary" className="mt-2">
                Rank #{inst1.rank}
              </Badge>
            </div>
            <div className="flex items-center justify-center">
              <div className="text-2xl font-bold text-muted-foreground">VS</div>
            </div>
            <div className="text-center">
              <div className="mb-3 flex h-16 w-16 mx-auto items-center justify-center rounded-lg bg-primary/10">
                <span className="text-2xl font-bold text-primary">{inst2.name[0]}</span>
              </div>
              <h3 className="mb-1 text-lg font-semibold">{inst2.name}</h3>
              <p className="text-sm text-muted-foreground">{inst2.country}</p>
              <Badge variant="secondary" className="mt-2">
                Rank #{inst2.rank}
              </Badge>
            </div>
          </div>

          <div className="space-y-0">
            <ComparisonRow
              label="Overall Score"
              value1={inst1.score}
              value2={inst2.score}
              isNumeric
            />
            <ComparisonRow
              label="Total Followers"
              value1={inst1.followers.toLocaleString()}
              value2={inst2.followers.toLocaleString()}
              isNumeric
            />
            <ComparisonRow
              label="Avg. Engagement"
              value1={`${inst1.engagement}%`}
              value2={`${inst2.engagement}%`}
              isNumeric
            />
            <ComparisonRow
              label="Growth Trend"
              value1={<TrendIndicator value={inst1.trend} />}
              value2={<TrendIndicator value={inst2.trend} />}
            />
          </div>
        </Card>

        {/* Platform Comparison */}
        <Card className="mt-8 p-6">
          <h2 className="mb-6 text-2xl font-semibold">Platform-by-Platform Comparison</h2>
          <div className="space-y-6">
            {Object.keys(inst1.platforms).map((platform) => {
              const p1 = inst1.platforms[platform as keyof typeof inst1.platforms];
              const p2 = inst2.platforms[platform as keyof typeof inst2.platforms];
              return (
                <div key={platform} className="border-b pb-6 last:border-0 last:pb-0">
                  <div className="mb-4">
                    <PlatformBadge platform={platform as any} />
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="rounded-lg border p-4">
                      <p className="mb-2 text-sm text-muted-foreground">{inst1.name}</p>
                      <div className="flex items-baseline gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Followers</p>
                          <p className="font-mono text-lg font-semibold">
                            {p1.followers.toLocaleString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Engagement</p>
                          <p className="font-mono text-lg font-semibold">{p1.engagement}%</p>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-lg border p-4">
                      <p className="mb-2 text-sm text-muted-foreground">{inst2.name}</p>
                      <div className="flex items-baseline gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Followers</p>
                          <p className="font-mono text-lg font-semibold">
                            {p2.followers.toLocaleString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Engagement</p>
                          <p className="font-mono text-lg font-semibold">{p2.engagement}%</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
