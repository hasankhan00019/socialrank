import { sql } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("analyst").notNull(), // super_admin, editor, analyst
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Institutions table
export const institutions = pgTable("institutions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  country: varchar("country").notNull(),
  type: varchar("type"), // e.g., "Private Research University"
  website: text("website"),
  logoUrl: text("logo_url"),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertInstitutionSchema = createInsertSchema(institutions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertInstitution = z.infer<typeof insertInstitutionSchema>;
export type Institution = typeof institutions.$inferSelect;

// Social Media Metrics table
export const socialMetrics = pgTable("social_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  institutionId: varchar("institution_id")
    .notNull()
    .references(() => institutions.id, { onDelete: "cascade" }),
  platform: varchar("platform").notNull(), // facebook, instagram, twitter, linkedin, youtube, tiktok
  followers: integer("followers").notNull(),
  engagement: decimal("engagement", { precision: 5, scale: 2 }).notNull(), // engagement rate as percentage
  recordedAt: date("recorded_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSocialMetricSchema = createInsertSchema(socialMetrics).omit({
  id: true,
  createdAt: true,
});

export type InsertSocialMetric = z.infer<typeof insertSocialMetricSchema>;
export type SocialMetric = typeof socialMetrics.$inferSelect;

// Ranking Weights table (configurable algorithm weights)
export const rankingWeights = pgTable("ranking_weights", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  platform: varchar("platform").notNull().unique(),
  weight: integer("weight").notNull(), // percentage (0-100)
  followerWeight: integer("follower_weight").default(50), // weight within platform score
  engagementWeight: integer("engagement_weight").default(50), // weight within platform score
  isActive: boolean("is_active").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertRankingWeightSchema = createInsertSchema(rankingWeights).omit({
  id: true,
  updatedAt: true,
});

export type InsertRankingWeight = z.infer<typeof insertRankingWeightSchema>;
export type RankingWeight = typeof rankingWeights.$inferSelect;

// Rankings Snapshots table (published rankings)
export const rankingSnapshots = pgTable("ranking_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  institutionId: varchar("institution_id")
    .notNull()
    .references(() => institutions.id, { onDelete: "cascade" }),
  platform: varchar("platform"), // null for combined ranking
  rank: integer("rank").notNull(),
  score: decimal("score", { precision: 5, scale: 2 }).notNull(),
  totalFollowers: integer("total_followers"),
  avgEngagement: decimal("avg_engagement", { precision: 5, scale: 2 }),
  trend: decimal("trend", { precision: 5, scale: 2 }), // growth percentage
  publishedAt: timestamp("published_at").notNull(),
  isPublished: boolean("is_published").default(true),
});

export const insertRankingSnapshotSchema = createInsertSchema(rankingSnapshots).omit({
  id: true,
});

export type InsertRankingSnapshot = z.infer<typeof insertRankingSnapshotSchema>;
export type RankingSnapshot = typeof rankingSnapshots.$inferSelect;

// Blog Posts table
export const blogPosts = pgTable("blog_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  featuredImageUrl: text("featured_image_url"),
  authorId: varchar("author_id")
    .notNull()
    .references(() => users.id),
  tags: text("tags").array(),
  status: varchar("status").default("draft").notNull(), // draft, published, scheduled
  scheduledAt: timestamp("scheduled_at"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;

// Media Assets table
export const mediaAssets = pgTable("media_assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: varchar("mime_type").notNull(),
  size: integer("size").notNull(), // in bytes
  url: text("url").notNull(),
  uploadedBy: varchar("uploaded_by")
    .notNull()
    .references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMediaAssetSchema = createInsertSchema(mediaAssets).omit({
  id: true,
  createdAt: true,
});

export type InsertMediaAsset = z.infer<typeof insertMediaAssetSchema>;
export type MediaAsset = typeof mediaAssets.$inferSelect;

// Content Blocks table (for homepage and methodology page content)
export const contentBlocks = pgTable("content_blocks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pageKey: varchar("page_key").notNull().unique(), // 'homepage', 'methodology'
  content: jsonb("content").notNull(), // structured content data
  updatedBy: varchar("updated_by")
    .notNull()
    .references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertContentBlockSchema = createInsertSchema(contentBlocks).omit({
  id: true,
  updatedAt: true,
});

export type InsertContentBlock = z.infer<typeof insertContentBlockSchema>;
export type ContentBlock = typeof contentBlocks.$inferSelect;

// Bulk Upload Jobs table
export const uploadJobs = pgTable("upload_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: varchar("type").notNull(), // 'institutions', 'metrics'
  filename: text("filename").notNull(),
  status: varchar("status").default("pending").notNull(), // pending, processing, completed, failed
  recordsTotal: integer("records_total"),
  recordsProcessed: integer("records_processed").default(0),
  recordsFailed: integer("records_failed").default(0),
  errorLog: text("error_log").array(),
  uploadedBy: varchar("uploaded_by")
    .notNull()
    .references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertUploadJobSchema = createInsertSchema(uploadJobs).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type InsertUploadJob = z.infer<typeof insertUploadJobSchema>;
export type UploadJob = typeof uploadJobs.$inferSelect;
