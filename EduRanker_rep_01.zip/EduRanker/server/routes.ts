import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, requireRole } from "./replitAuth";
import multer from "multer";
import { z } from "zod";
import {
  insertInstitutionSchema,
  insertSocialMetricSchema,
  insertRankingWeightSchema,
  insertBlogPostSchema,
  insertContentBlockSchema,
} from "@shared/schema";

const upload = multer({ dest: "uploads/" });

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // ========== ADMIN ROUTES ==========

  // User Management (Super Admin only)
  app.patch(
    "/api/admin/users/:id/role",
    isAuthenticated,
    requireRole(["super_admin"]),
    async (req, res) => {
      try {
        const { id } = req.params;
        const { role } = req.body;

        if (!["super_admin", "editor", "analyst"].includes(role)) {
          return res.status(400).json({ message: "Invalid role" });
        }

        const user = await storage.updateUserRole(id, role);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }

        res.json(user);
      } catch (error) {
        console.error("Error updating user role:", error);
        res.status(500).json({ message: "Failed to update user role" });
      }
    }
  );

  // Institution Management (Read-only for all authenticated users)
  app.get("/api/admin/institutions", isAuthenticated, async (req, res) => {
    try {
      const { search } = req.query;
      let institutions;

      if (search && typeof search === "string") {
        institutions = await storage.searchInstitutions(search);
      } else {
        institutions = await storage.getAllInstitutions();
      }

      res.json(institutions);
    } catch (error) {
      console.error("Error fetching institutions:", error);
      res.status(500).json({ message: "Failed to fetch institutions" });
    }
  });

  app.get("/api/admin/institutions/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const institution = await storage.getInstitution(id);

      if (!institution) {
        return res.status(404).json({ message: "Institution not found" });
      }

      res.json(institution);
    } catch (error) {
      console.error("Error fetching institution:", error);
      res.status(500).json({ message: "Failed to fetch institution" });
    }
  });

  app.post(
    "/api/admin/institutions",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req, res) => {
      try {
        const validated = insertInstitutionSchema.parse(req.body);
        const institution = await storage.createInstitution(validated);
        res.json(institution);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Validation error", errors: error.errors });
        }
        console.error("Error creating institution:", error);
        res.status(500).json({ message: "Failed to create institution" });
      }
    }
  );

  app.patch(
    "/api/admin/institutions/:id",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req, res) => {
      try {
        const { id } = req.params;
        const institution = await storage.updateInstitution(id, req.body);

        if (!institution) {
          return res.status(404).json({ message: "Institution not found" });
        }

        res.json(institution);
      } catch (error) {
        console.error("Error updating institution:", error);
        res.status(500).json({ message: "Failed to update institution" });
      }
    }
  );

  app.delete(
    "/api/admin/institutions/:id",
    isAuthenticated,
    requireRole(["super_admin"]),
    async (req, res) => {
      try {
        const { id } = req.params;
        await storage.deleteInstitution(id);
        res.json({ message: "Institution deleted successfully" });
      } catch (error) {
        console.error("Error deleting institution:", error);
        res.status(500).json({ message: "Failed to delete institution" });
      }
    }
  );

  // Social Metrics (Read-only for all authenticated users)
  app.get(
    "/api/admin/institutions/:id/metrics",
    isAuthenticated,
    async (req, res) => {
      try {
        const { id } = req.params;
        const metrics = await storage.getMetricsByInstitution(id);
        res.json(metrics);
      } catch (error) {
        console.error("Error fetching metrics:", error);
        res.status(500).json({ message: "Failed to fetch metrics" });
      }
    }
  );

  app.post(
    "/api/admin/metrics",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req, res) => {
      try {
        const validated = insertSocialMetricSchema.parse(req.body);
        const metric = await storage.createSocialMetric(validated);
        res.json(metric);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Validation error", errors: error.errors });
        }
        console.error("Error creating metric:", error);
        res.status(500).json({ message: "Failed to create metric" });
      }
    }
  );

  // Ranking Weights (Read-only for all authenticated users)
  app.get("/api/admin/ranking-weights", isAuthenticated, async (req, res) => {
    try {
      const weights = await storage.getAllRankingWeights();
      res.json(weights);
    } catch (error) {
      console.error("Error fetching ranking weights:", error);
      res.status(500).json({ message: "Failed to fetch ranking weights" });
    }
  });

  app.post(
    "/api/admin/ranking-weights",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req, res) => {
      try {
        const validated = insertRankingWeightSchema.parse(req.body);
        const weight = await storage.upsertRankingWeight(validated);
        res.json(weight);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Validation error", errors: error.errors });
        }
        console.error("Error updating ranking weight:", error);
        res.status(500).json({ message: "Failed to update ranking weight" });
      }
    }
  );

  // Blog Posts (Read-only for all authenticated users)
  app.get("/api/admin/blog-posts", isAuthenticated, async (req, res) => {
    try {
      const { status } = req.query;
      const posts = await storage.getAllBlogPosts(status as string | undefined);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });

  app.get("/api/admin/blog-posts/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const post = await storage.getBlogPost(id);

      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }

      res.json(post);
    } catch (error) {
      console.error("Error fetching blog post:", error);
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });

  app.post(
    "/api/admin/blog-posts",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req: any, res) => {
      try {
        const userId = req.user.claims.sub;
        const validated = insertBlogPostSchema.parse({
          ...req.body,
          authorId: userId,
        });
        const post = await storage.createBlogPost(validated);
        res.json(post);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Validation error", errors: error.errors });
        }
        console.error("Error creating blog post:", error);
        res.status(500).json({ message: "Failed to create blog post" });
      }
    }
  );

  app.patch(
    "/api/admin/blog-posts/:id",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req, res) => {
      try {
        const { id } = req.params;
        const post = await storage.updateBlogPost(id, req.body);

        if (!post) {
          return res.status(404).json({ message: "Blog post not found" });
        }

        res.json(post);
      } catch (error) {
        console.error("Error updating blog post:", error);
        res.status(500).json({ message: "Failed to update blog post" });
      }
    }
  );

  app.delete(
    "/api/admin/blog-posts/:id",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req, res) => {
      try {
        const { id } = req.params;
        await storage.deleteBlogPost(id);
        res.json({ message: "Blog post deleted successfully" });
      } catch (error) {
        console.error("Error deleting blog post:", error);
        res.status(500).json({ message: "Failed to delete blog post" });
      }
    }
  );

  // Content Blocks
  app.get("/api/admin/content/:pageKey", isAuthenticated, async (req, res) => {
    try {
      const { pageKey } = req.params;
      const content = await storage.getContentBlock(pageKey);
      res.json(content || null);
    } catch (error) {
      console.error("Error fetching content block:", error);
      res.status(500).json({ message: "Failed to fetch content block" });
    }
  });

  app.post(
    "/api/admin/content",
    isAuthenticated,
    requireRole(["super_admin", "editor"]),
    async (req: any, res) => {
      try {
        const userId = req.user.claims.sub;
        const validated = insertContentBlockSchema.parse({
          ...req.body,
          updatedBy: userId,
        });
        const content = await storage.upsertContentBlock(validated);
        res.json(content);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Validation error", errors: error.errors });
        }
        console.error("Error updating content block:", error);
        res.status(500).json({ message: "Failed to update content block" });
      }
    }
  );

  // Media Assets
  app.get("/api/admin/media", isAuthenticated, async (req, res) => {
    try {
      const media = await storage.getAllMediaAssets();
      res.json(media);
    } catch (error) {
      console.error("Error fetching media:", error);
      res.status(500).json({ message: "Failed to fetch media" });
    }
  });

  // Analytics
  app.get("/api/admin/analytics/overview", isAuthenticated, async (req, res) => {
    try {
      const institutions = await storage.getAllInstitutions();
      const blogPosts = await storage.getAllBlogPosts("published");

      res.json({
        totalInstitutions: institutions.length,
        totalPublishedPosts: blogPosts.length,
        institutionsVerified: institutions.filter((i) => i.verified).length,
      });
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
