import {
  users,
  institutions,
  socialMetrics,
  rankingWeights,
  rankingSnapshots,
  blogPosts,
  mediaAssets,
  contentBlocks,
  uploadJobs,
  type User,
  type UpsertUser,
  type Institution,
  type InsertInstitution,
  type SocialMetric,
  type InsertSocialMetric,
  type RankingWeight,
  type InsertRankingWeight,
  type RankingSnapshot,
  type InsertRankingSnapshot,
  type BlogPost,
  type InsertBlogPost,
  type MediaAsset,
  type InsertMediaAsset,
  type ContentBlock,
  type InsertContentBlock,
  type UploadJob,
  type InsertUploadJob,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql, like } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserRole(id: string, role: string): Promise<User | undefined>;
  
  // Institution operations
  getAllInstitutions(): Promise<Institution[]>;
  getInstitution(id: string): Promise<Institution | undefined>;
  getInstitutionByName(name: string): Promise<Institution | undefined>;
  createInstitution(institution: InsertInstitution): Promise<Institution>;
  updateInstitution(id: string, data: Partial<InsertInstitution>): Promise<Institution | undefined>;
  deleteInstitution(id: string): Promise<void>;
  searchInstitutions(query: string): Promise<Institution[]>;
  
  // Social Metrics operations
  getMetricsByInstitution(institutionId: string): Promise<SocialMetric[]>;
  getLatestMetricsByInstitution(institutionId: string): Promise<SocialMetric[]>;
  createSocialMetric(metric: InsertSocialMetric): Promise<SocialMetric>;
  bulkCreateSocialMetrics(metrics: InsertSocialMetric[]): Promise<SocialMetric[]>;
  
  // Ranking Weights operations
  getAllRankingWeights(): Promise<RankingWeight[]>;
  getRankingWeight(platform: string): Promise<RankingWeight | undefined>;
  upsertRankingWeight(weight: InsertRankingWeight): Promise<RankingWeight>;
  
  // Ranking Snapshots operations
  getPublishedRankings(platform?: string): Promise<RankingSnapshot[]>;
  createRankingSnapshot(snapshot: InsertRankingSnapshot): Promise<RankingSnapshot>;
  bulkCreateRankingSnapshots(snapshots: InsertRankingSnapshot[]): Promise<RankingSnapshot[]>;
  
  // Blog Posts operations
  getAllBlogPosts(status?: string): Promise<BlogPost[]>;
  getBlogPost(id: string): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: string, data: Partial<InsertBlogPost>): Promise<BlogPost | undefined>;
  deleteBlogPost(id: string): Promise<void>;
  
  // Media Assets operations
  getAllMediaAssets(): Promise<MediaAsset[]>;
  createMediaAsset(asset: InsertMediaAsset): Promise<MediaAsset>;
  deleteMediaAsset(id: string): Promise<void>;
  
  // Content Blocks operations
  getContentBlock(pageKey: string): Promise<ContentBlock | undefined>;
  upsertContentBlock(block: InsertContentBlock): Promise<ContentBlock>;
  
  // Upload Jobs operations
  createUploadJob(job: InsertUploadJob): Promise<UploadJob>;
  updateUploadJob(id: string, data: Partial<InsertUploadJob>): Promise<UploadJob | undefined>;
  getUploadJob(id: string): Promise<UploadJob | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserRole(id: string, role: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Institution operations
  async getAllInstitutions(): Promise<Institution[]> {
    return await db.select().from(institutions).orderBy(institutions.name);
  }

  async getInstitution(id: string): Promise<Institution | undefined> {
    const [institution] = await db
      .select()
      .from(institutions)
      .where(eq(institutions.id, id));
    return institution;
  }

  async getInstitutionByName(name: string): Promise<Institution | undefined> {
    const [institution] = await db
      .select()
      .from(institutions)
      .where(eq(institutions.name, name));
    return institution;
  }

  async createInstitution(institution: InsertInstitution): Promise<Institution> {
    const [created] = await db
      .insert(institutions)
      .values(institution)
      .returning();
    return created;
  }

  async updateInstitution(
    id: string,
    data: Partial<InsertInstitution>
  ): Promise<Institution | undefined> {
    const [updated] = await db
      .update(institutions)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(institutions.id, id))
      .returning();
    return updated;
  }

  async deleteInstitution(id: string): Promise<void> {
    await db.delete(institutions).where(eq(institutions.id, id));
  }

  async searchInstitutions(query: string): Promise<Institution[]> {
    return await db
      .select()
      .from(institutions)
      .where(like(institutions.name, `%${query}%`))
      .orderBy(institutions.name);
  }

  // Social Metrics operations
  async getMetricsByInstitution(institutionId: string): Promise<SocialMetric[]> {
    return await db
      .select()
      .from(socialMetrics)
      .where(eq(socialMetrics.institutionId, institutionId))
      .orderBy(desc(socialMetrics.recordedAt));
  }

  async getLatestMetricsByInstitution(
    institutionId: string
  ): Promise<SocialMetric[]> {
    const latestMetrics = await db
      .select()
      .from(socialMetrics)
      .where(eq(socialMetrics.institutionId, institutionId))
      .orderBy(desc(socialMetrics.recordedAt))
      .limit(6);
    return latestMetrics;
  }

  async createSocialMetric(metric: InsertSocialMetric): Promise<SocialMetric> {
    const [created] = await db.insert(socialMetrics).values(metric).returning();
    return created;
  }

  async bulkCreateSocialMetrics(
    metrics: InsertSocialMetric[]
  ): Promise<SocialMetric[]> {
    if (metrics.length === 0) return [];
    return await db.insert(socialMetrics).values(metrics).returning();
  }

  // Ranking Weights operations
  async getAllRankingWeights(): Promise<RankingWeight[]> {
    return await db.select().from(rankingWeights);
  }

  async getRankingWeight(platform: string): Promise<RankingWeight | undefined> {
    const [weight] = await db
      .select()
      .from(rankingWeights)
      .where(eq(rankingWeights.platform, platform));
    return weight;
  }

  async upsertRankingWeight(weight: InsertRankingWeight): Promise<RankingWeight> {
    const [result] = await db
      .insert(rankingWeights)
      .values(weight)
      .onConflictDoUpdate({
        target: rankingWeights.platform,
        set: {
          ...weight,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  // Ranking Snapshots operations
  async getPublishedRankings(platform?: string): Promise<RankingSnapshot[]> {
    const query = db
      .select()
      .from(rankingSnapshots)
      .where(eq(rankingSnapshots.isPublished, true));

    if (platform) {
      return await query
        .where(
          and(
            eq(rankingSnapshots.isPublished, true),
            eq(rankingSnapshots.platform, platform)
          )
        )
        .orderBy(rankingSnapshots.rank);
    }

    return await query.orderBy(rankingSnapshots.rank);
  }

  async createRankingSnapshot(
    snapshot: InsertRankingSnapshot
  ): Promise<RankingSnapshot> {
    const [created] = await db
      .insert(rankingSnapshots)
      .values(snapshot)
      .returning();
    return created;
  }

  async bulkCreateRankingSnapshots(
    snapshots: InsertRankingSnapshot[]
  ): Promise<RankingSnapshot[]> {
    if (snapshots.length === 0) return [];
    return await db.insert(rankingSnapshots).values(snapshots).returning();
  }

  // Blog Posts operations
  async getAllBlogPosts(status?: string): Promise<BlogPost[]> {
    if (status) {
      return await db
        .select()
        .from(blogPosts)
        .where(eq(blogPosts.status, status))
        .orderBy(desc(blogPosts.createdAt));
    }
    return await db
      .select()
      .from(blogPosts)
      .orderBy(desc(blogPosts.createdAt));
  }

  async getBlogPost(id: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post;
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.slug, slug));
    return post;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [created] = await db.insert(blogPosts).values(post).returning();
    return created;
  }

  async updateBlogPost(
    id: string,
    data: Partial<InsertBlogPost>
  ): Promise<BlogPost | undefined> {
    const [updated] = await db
      .update(blogPosts)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(blogPosts.id, id))
      .returning();
    return updated;
  }

  async deleteBlogPost(id: string): Promise<void> {
    await db.delete(blogPosts).where(eq(blogPosts.id, id));
  }

  // Media Assets operations
  async getAllMediaAssets(): Promise<MediaAsset[]> {
    return await db
      .select()
      .from(mediaAssets)
      .orderBy(desc(mediaAssets.createdAt));
  }

  async createMediaAsset(asset: InsertMediaAsset): Promise<MediaAsset> {
    const [created] = await db.insert(mediaAssets).values(asset).returning();
    return created;
  }

  async deleteMediaAsset(id: string): Promise<void> {
    await db.delete(mediaAssets).where(eq(mediaAssets.id, id));
  }

  // Content Blocks operations
  async getContentBlock(pageKey: string): Promise<ContentBlock | undefined> {
    const [block] = await db
      .select()
      .from(contentBlocks)
      .where(eq(contentBlocks.pageKey, pageKey));
    return block;
  }

  async upsertContentBlock(block: InsertContentBlock): Promise<ContentBlock> {
    const [result] = await db
      .insert(contentBlocks)
      .values(block)
      .onConflictDoUpdate({
        target: contentBlocks.pageKey,
        set: {
          ...block,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  // Upload Jobs operations
  async createUploadJob(job: InsertUploadJob): Promise<UploadJob> {
    const [created] = await db.insert(uploadJobs).values(job).returning();
    return created;
  }

  async updateUploadJob(
    id: string,
    data: Partial<InsertUploadJob>
  ): Promise<UploadJob | undefined> {
    const [updated] = await db
      .update(uploadJobs)
      .set(data)
      .where(eq(uploadJobs.id, id))
      .returning();
    return updated;
  }

  async getUploadJob(id: string): Promise<UploadJob | undefined> {
    const [job] = await db.select().from(uploadJobs).where(eq(uploadJobs.id, id));
    return job;
  }
}

export const storage = new DatabaseStorage();
