# SociaLearn Index - Design Guidelines

## Design Approach

**Selected Approach:** Modern Data-Focused Design System  
**Inspiration:** Linear's typography and spacing precision + Vercel's minimalist clarity + Material Design's data visualization patterns

**Rationale:** As a data-heavy analytics platform for university rankings, the design prioritizes information clarity, professional credibility, and efficient data consumption. The interface should feel authoritative yet approachable, with excellent readability and intuitive data navigation.

---

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 220 90% 56% (Deep blue - trust, authority, education)
- Primary Hover: 220 90% 48%
- Background: 0 0% 100%
- Surface: 220 15% 97%
- Border: 220 13% 91%
- Text Primary: 220 20% 15%
- Text Secondary: 220 10% 45%
- Success: 142 76% 36% (growth indicators)
- Warning: 38 92% 50% (trending alerts)
- Muted: 220 13% 65%

**Dark Mode:**
- Primary: 220 90% 60%
- Primary Hover: 220 90% 65%
- Background: 220 20% 8%
- Surface: 220 18% 12%
- Border: 220 15% 20%
- Text Primary: 220 15% 95%
- Text Secondary: 220 10% 65%
- Success: 142 76% 45%
- Warning: 38 92% 60%

**Accent Colors (Minimal Use):**
- Chart Colors: Use distinct hues for multi-platform data (Facebook: 221 83% 53%, Instagram: 340 75% 60%, LinkedIn: 201 100% 35%, YouTube: 0 100% 50%, TikTok: 180 90% 50%, X/Twitter: 0 0% 15%)

---

### B. Typography

**Font Stack:**  
- Primary: Inter (Google Fonts) - exceptional readability for data
- Monospace: JetBrains Mono - for numeric values and metrics

**Hierarchy:**
- Hero Headlines: text-6xl font-bold tracking-tight (3.75rem)
- Page Headlines: text-4xl font-bold tracking-tight (2.25rem)
- Section Headers: text-2xl font-semibold (1.5rem)
- Card Titles: text-lg font-semibold (1.125rem)
- Body Text: text-base font-normal (1rem)
- Captions/Labels: text-sm font-medium (0.875rem)
- Numeric Data: text-2xl font-mono font-semibold
- Small Metrics: text-xs font-mono (0.75rem)

**Line Heights:** Use relaxed leading for body text (leading-relaxed), tighter for headlines (leading-tight)

---

### C. Layout System

**Spacing Primitives:** Consistent use of 4, 6, 8, 12, 16, 20, 24 units  
- Component padding: p-6 or p-8
- Section spacing: py-16 or py-20 on desktop, py-12 on mobile
- Card gaps: gap-6 or gap-8
- Element margins: mb-4, mb-6, mb-8

**Container Widths:**
- Full-width sections: w-full with inner max-w-7xl mx-auto px-6
- Content sections: max-w-6xl mx-auto
- Reading content (blog): max-w-3xl mx-auto

**Grid System:**
- Rankings tables: Single column on mobile, full-width on desktop
- Feature cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Stats display: grid-cols-2 md:grid-cols-4
- Comparison view: grid-cols-1 lg:grid-cols-2 (side-by-side)

---

### D. Component Library

**Navigation:**
- Sticky header with blur backdrop (backdrop-blur-md bg-white/80 dark:bg-background/80)
- Logo + primary navigation links + CTA button
- Mobile: Hamburger menu with slide-out drawer
- Admin: Sidebar navigation with collapsible sections

**Cards & Containers:**
- Ranking cards: White/dark surface with subtle border, hover state with shadow elevation
- Institution cards: Image thumbnail + name + stats grid
- Stat cards: Large numeric value + label + trend indicator (↑/↓ with percentage)
- Border radius: rounded-lg (0.5rem) for cards, rounded-xl (0.75rem) for larger containers

**Data Tables:**
- Sticky header row with sort indicators
- Alternating row backgrounds for readability (subtle stripe)
- Hover state highlighting entire row
- Responsive: Stack to cards on mobile with key metrics visible

**Charts & Visualizations:**
- Line charts for historical trends (6-month, 1-year views)
- Bar charts for platform comparisons
- Radial/donut charts for engagement breakdowns
- Use consistent color mapping across all charts
- Tooltip on hover with precise values

**Buttons:**
- Primary: bg-primary text-white with hover brightness
- Secondary: border with hover background fill
- Ghost: text-only with hover background
- Sizes: px-6 py-3 (default), px-4 py-2 (small), px-8 py-4 (large)

**Forms (Admin):**
- Consistent input styling: border, focus ring in primary color
- Labels above inputs with required asterisk
- Validation states: green border (success), red border (error)
- Bulk upload: Drag-and-drop zone with file preview

**Badges & Tags:**
- Platform badges: Small pills with platform icon + name
- Rank badges: #1, #2, #3 with gold/silver/bronze subtle backgrounds
- Trend indicators: Small pill with ↑ or ↓ icon + percentage

**Modals & Overlays:**
- Comparison modal: Full-screen or large centered modal
- Delete confirmations: Centered small modal with clear actions
- Background overlay: bg-black/50 backdrop-blur-sm

---

### E. Page-Specific Design

**Homepage:**
- Hero section (min-h-[600px]): Large background gradient (subtle), centered headline, top 5 institutions preview cards, dual CTAs
- Global stats section: 4-column grid with animated counters
- Featured rankings preview: Horizontal scrollable cards or 3-column grid
- Recent insights: Blog post cards with thumbnail images

**Rankings Hub:**
- Sticky filter sidebar (desktop) or collapsible panel (mobile)
- Main ranking table with search bar at top
- Tab navigation for platform-specific views
- Export button positioned top-right

**Institution Profile:**
- Header with institution logo, name, country flag, verified badge
- Key metrics row: Follower count, engagement rate, rank position, growth percentage
- Platform links row: Icon buttons to official social accounts
- Charts section: 2-column grid on desktop with toggle for timeframe
- Compare CTA: Floating or sticky button

**Methodology Page:**
- Clean single-column layout (max-w-3xl)
- Formula breakdowns with visual diagrams
- Collapsible sections for each platform's methodology
- Transparency emphasis with highlighted callouts

**Admin Dashboard:**
- Left sidebar navigation with grouped sections
- Top bar with user profile + notifications
- Dashboard cards with quick stats
- Data tables with inline editing capabilities
- Bulk action toolbar when rows selected

---

### F. Images

**Homepage Hero:** Large, high-quality image showing diverse university students or iconic campus architecture with overlay gradient for text legibility. Image should span full width, height 600-800px.

**Institution Profiles:** University logo (square, 120x120px) and optional banner image (1200x400px) showing campus.

**Blog Posts:** Featured image (16:9 ratio, 1200x675px) for each article.

**Placeholder States:** Use subtle illustrations or icon-based empty states for no data scenarios.

---

### G. Interaction & Animation

**Micro-interactions (Minimal):**
- Hover state transitions: duration-200 ease-in-out
- Card elevation on hover: shadow-md to shadow-lg
- Button press: subtle scale transform (scale-95)
- Number counters: Animate on scroll into view (count-up effect)

**Page Transitions:** Fade-in content on route change (150ms)

**Loading States:** Skeleton screens matching content layout, subtle pulse animation

**Avoid:** Excessive motion, auto-playing carousels, distracting background animations

---

### H. Accessibility & Responsiveness

- Maintain WCAG AA contrast ratios (4.5:1 for normal text)
- Focus indicators: 2px ring in primary color with offset
- Semantic HTML: proper heading hierarchy, ARIA labels for icons
- Keyboard navigation: Full support for all interactive elements
- Mobile breakpoints: Prioritize single-column layouts, larger touch targets (min 44x44px)
- Dark mode: Consistent implementation across all pages with user preference persistence

---

## Design Principles

1. **Data First:** Information architecture prioritizes quick access to rankings and metrics
2. **Professional Authority:** Clean, minimal aesthetic establishes credibility
3. **Scanability:** Clear typography hierarchy and spacing enable rapid data consumption
4. **Responsive Precision:** Layouts adapt gracefully without sacrificing data clarity
5. **Trustworthy Transparency:** Open methodology and clear data sourcing build user confidence